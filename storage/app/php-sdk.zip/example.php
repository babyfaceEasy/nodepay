<?php
    require 'vendor/autoload.php';
    use PayMoney\Api\Payer;
    use PayMoney\Api\Amount;
    use PayMoney\Api\Transaction;
    use PayMoney\Api\RedirectUrls;
    use PayMoney\Api\Payment;

    $payer = new Payer();
    $payer->setPaymentMethod('paymoney');

    $amountIns = new Amount();
    $amountIns->setTotal(20)
        ->setCurrency('USD'); // currency must be in merchant wallet list

    $trans = new Transaction();
    $trans->setAmount($amountIns);

    $urls = new RedirectUrls();
    $urls->setReturnUrl('http://localhost/return-url')
        ->setCancelUrl('http://localhost/cancel-url');

    $payment = new Payment();
    $payment->setCredentials([
        'client_id' => 'FAUjfurHvuP8v8c9BMlRfcttH1MhbR',
        'client_secret' => 'oFFtt13bmxxb6AbAxNYiRXzlioa0H4mKE3dI7V5RAc9lVos1muzdq8IInc5jsBPW7kLLSIQspxbDHr9U2Dz1nhhxZlpVMyJ9KUf9'
    ])
        ->setRedirectUrls($urls)
        ->setPayer($payer)
        ->setTransaction($trans);

    try {
        $payment->create();
        header("Location: ".$payment->getApprovedUrl());
    } catch (\Exception $ex) {
        print $ex;
        exit;
    }





